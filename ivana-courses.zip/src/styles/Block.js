import React from "react";

export const Block = ({ children, background }) => (
  <div style={{ padding: "30px 100px", background }}>{children}</div>
);
